from setuptools import setup, find_packages

setup(
    name="drone_ai",
    version="1.0.0",
    description="AI-driven drone control system using Google Vision API.",
    packages=find_packages(),
    install_requires=[
        "google-cloud-vision"
    ],
    python_requires=">=3.7",
)