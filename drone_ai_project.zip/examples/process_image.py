from drone_ai.controller import DroneController
from drone_ai.vision_analyzer import VisionAnalyzer
from drone_ai.drone_api import DroneAPI

if __name__ == "__main__":
    # Initialize components
    vision_analyzer = VisionAnalyzer(api_key_path="path/to/vision_api_key.json")
    drone_api = DroneAPI()
    controller = DroneController(drone_api, vision_analyzer)
    
    # Process an image and control the drone
    controller.process_and_control("example_image.jpg", drone_id=1)