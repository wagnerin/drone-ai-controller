from .vision_analyzer import VisionAnalyzer
from .drone_api import DroneAPI

class DroneController:
    """
    The main controller for managing drone actions based on AI analysis.
    """
    
    def __init__(self, drone_api: DroneAPI, vision_analyzer: VisionAnalyzer):
        self.drone_api = drone_api
        self.vision_analyzer = vision_analyzer

    def process_and_control(self, image_path: str, drone_id: int):
        """
        Analyze an image and control the drone based on the results.

        Args:
            image_path (str): Path to the image from the drone's camera.
            drone_id (int): The ID of the drone to control.
        """
        analysis = self.vision_analyzer.analyze_image(image_path)
        
        # Example decision-making logic
        if "field" in analysis and analysis["field"] > 0.8:
            self.drone_api.send_command(drone_id, "move_forward")
        elif "obstacle" in analysis and analysis["obstacle"] > 0.5:
            self.drone_api.send_command(drone_id, "move_backward")
        else:
            self.drone_api.send_command(drone_id, "stop")