import os
from google.cloud import vision

class VisionAnalyzer:
    """
    Handles image analysis using Google Vision API.
    """
    
    def __init__(self, api_key_path: str):
        os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = api_key_path
        self.client = vision.ImageAnnotatorClient()

    def analyze_image(self, image_path: str) -> dict:
        """
        Analyze an image using Google Vision API.

        Args:
            image_path (str): Path to the image.

        Returns:
            dict: Detected labels and their confidence scores.
        """
        try:
            with open(image_path, "rb") as image_file:
                content = image_file.read()
            image = vision.Image(content=content)
            response = self.client.label_detection(image=image)
            labels = response.label_annotations
            return {label.description: label.score for label in labels}
        except Exception as e:
            print(f"Error analyzing image: {e}")
            return {}