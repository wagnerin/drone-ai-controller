class DroneAPI:
    """
    Mock API for sending commands to drones.
    Replace with actual drone API in production.
    """

    def send_command(self, drone_id: int, command: str) -> bool:
        """
        Send a command to a drone.

        Args:
            drone_id (int): The ID of the drone.
            command (str): The command to send.

        Returns:
            bool: Whether the command was successful.
        """
        try:
            print(f"Sending command '{command}' to drone {drone_id}.")
            return True
        except Exception as e:
            print(f"Error sending command: {e}")
            return False